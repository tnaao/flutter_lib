package io.agora.iris_event.iris_event_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
