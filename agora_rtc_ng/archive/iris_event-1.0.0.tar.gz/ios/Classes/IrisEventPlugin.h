#import <Flutter/Flutter.h>

@interface IrisEventPlugin : NSObject<FlutterPlugin>
@end
