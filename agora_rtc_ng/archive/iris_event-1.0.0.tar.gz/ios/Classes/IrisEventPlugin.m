#import "IrisEventPlugin.h"

@implementation IrisEventPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
}
@end
