# iris_event

iris_event is a bridge of iris event handling, which is only used internally, NOTE that you should not use it.

## License

The project is under the MIT license.